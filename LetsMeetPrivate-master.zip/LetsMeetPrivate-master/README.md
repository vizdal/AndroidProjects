# Let's Meet
An application with the aim of organizing meetings in an easy fashion.
